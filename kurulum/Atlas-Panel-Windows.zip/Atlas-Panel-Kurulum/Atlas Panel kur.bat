@echo off
chcp 65001 >nul
rem Atlas Panel: masaustune okul logolu simge koyar (Edge uygulama penceresi). Yonetici izni gerekmez.
set "HEDEF=%LOCALAPPDATA%\AtlasPanel"
if not exist "%HEDEF%" mkdir "%HEDEF%"
copy /y "%~dp0atlas.ico" "%HEDEF%\atlas.ico" >nul
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w=New-Object -ComObject WScript.Shell; $m=[Environment]::GetFolderPath('Desktop'); foreach($y in @($m, [Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut((Join-Path $y 'Atlas Panel.lnk')); $s.TargetPath=$env:EDGE; $s.Arguments='--app=https://299ygp9529-prog.github.io/umal-okul-paneli/'; $s.IconLocation=(Join-Path $env:HEDEF 'atlas.ico'); $s.Description='UMAL Okul Yonetim Paneli'; $s.Save() }"
echo.
echo Atlas Panel simgesi masaustune ve Baslat menusune eklendi.
pause
